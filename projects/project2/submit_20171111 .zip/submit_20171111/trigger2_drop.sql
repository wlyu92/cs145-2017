PRAGMA foreign_keys = ON;
drop trigger no_bid_on_self;
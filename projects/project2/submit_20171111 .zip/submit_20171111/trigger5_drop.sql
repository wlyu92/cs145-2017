PRAGMA foreign_keys = ON;
drop trigger bid_amount;
PRAGMA foreign_keys = ON;
drop trigger advance_current_time;
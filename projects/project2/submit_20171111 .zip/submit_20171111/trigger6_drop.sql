PRAGMA foreign_keys = ON;
drop trigger update_bid_time;
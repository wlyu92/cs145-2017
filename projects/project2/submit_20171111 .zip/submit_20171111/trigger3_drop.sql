PRAGMA foreign_keys = ON;
drop trigger auction_time;
PRAGMA foreign_keys = ON;
drop trigger update_num_of_bids;